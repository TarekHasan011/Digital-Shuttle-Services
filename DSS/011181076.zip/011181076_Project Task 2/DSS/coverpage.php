<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Home</title>
  </head>
  <body>
    <div id="cover0" align="right">
      <h3><a href="login.php">Login</a>
      <a href="#">Signup</a>
      <a href="#">Apply to be driver</a></h3>
    </div>
    <div id="cover1" align="center">
        <h1>DIGITAL</h1>
        <h1>SHUTTLE SERVICE</h1>
        <h4>An Online Platform for Shuttle Service of an Organization or Institution</h6>
    </div>
  </body>
</html>
